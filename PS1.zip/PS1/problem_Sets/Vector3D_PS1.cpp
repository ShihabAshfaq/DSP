//
//  Vector3D_PS1.cpp
//  problem_Sets
//
//  Created by H M Asfaq Ahmed Shihab on 23/3/2024.
#include "Vector3D.hpp"
#include <sstream>
#include <iomanip>

std::string Vector3D::toString() const noexcept {
    std::stringstream ss;
    ss << std::fixed << std::setprecision(4);
    ss << "[" << x() << ", " << y() << ", " << w() << "]";
    return ss.str();
}
