//
//  Ploygon_PS1.cpp
//  problem_Sets
//
//  Created by H M Asfaq Ahmed Shihab on 24/3/2024.
//
#include <cassert>
#include "Polygon.hpp"
#include "Vector3D.hpp" // Include necessary header for Vector3D

float Polygon::getSignedArea() const noexcept {
    float lArea = 0.0f;
    assert(fNumberOfVertices > 2);
    for (size_t i = 0; i < fNumberOfVertices - 1; i++) {
        lArea += 0.5f * (fVertices[i].y() + fVertices[i + 1].y()) * (fVertices[i].x() - fVertices[i + 1].x());
    }
    // Calculate area for the last vertex and the first vertex
    lArea += 0.5f * (fVertices[fNumberOfVertices - 1].y() + fVertices[0].y()) * (fVertices[fNumberOfVertices - 1].x() - fVertices[0].x());
    return lArea;
}

Polygon Polygon::transform(const Matrix3x3& aMatrix) const noexcept {
    Polygon lTransform = *this; // Make a copy of the current polygon to transform
    Vector3D lTransformVec;
    for (size_t i = 0; i < fNumberOfVertices; i++) {
        // Convert Vector2D to Vector3D
        lTransformVec = Vector3D(fVertices[i].x(), fVertices[i].y(), 1.0f);
        // Apply transformation using Matrix3x3
        lTransformVec = aMatrix * lTransformVec;
        // Convert back to Vector2D
        lTransform.fVertices[i] = Vector2D(lTransformVec.x(), lTransformVec.y());
    }
    return lTransform;
}
